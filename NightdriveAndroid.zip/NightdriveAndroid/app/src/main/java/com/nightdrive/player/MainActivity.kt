package com.nightdrive.player

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF0E0F22); private val Card = Color(0xFF181A37)
private val Violet = Color(0xFF8B73FF); private val Pink = Color(0xFFFF6B9A); private val Mute = Color(0xFF9A9CC4)
private val Grad = Brush.linearGradient(listOf(Violet, Pink))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Bg, surface = Card)) { App() }
        }
    }
}

fun scanSongs(ctx: Context): List<MediaItem> {
    val out = mutableListOf<MediaItem>()
    val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val cols = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
    ctx.contentResolver.query(uri, cols, "${MediaStore.Audio.Media.IS_MUSIC}!=0 AND ${MediaStore.Audio.Media.DURATION}>30000", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE")?.use { c ->
        while (c.moveToNext()) {
            val id = c.getLong(0)
            val artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: "Unknown artist"
            out += MediaItem.Builder().setMediaId(id.toString()).setUri(ContentUris.withAppendedId(uri, id))
                .setMediaMetadata(MediaMetadata.Builder().setTitle(c.getString(1)).setArtist(artist).build()).build()
        }
    }
    return out
}

fun fmt(ms: Long): String { val s = (ms.coerceAtLeast(0) / 1000).toInt(); return "%d:%02d".format(s / 60, s % 60) }

@Composable
fun App() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var ctl by remember { mutableStateOf<MediaController?>(null) }
    var songs by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var scanned by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var cur by remember { mutableStateOf<MediaItem?>(null) }
    var pos by remember { mutableStateOf(0L) }
    var dur by remember { mutableStateOf(0L) }
    var drag by remember { mutableStateOf<Float?>(null) }
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var denied by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val f = MediaController.Builder(ctx, token).buildAsync()
        f.addListener({
            val c = f.get(); ctl = c
            playing = c.isPlaying; cur = c.currentMediaItem
            c.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(p: Boolean) { playing = p }
                override fun onMediaItemTransition(m: MediaItem?, r: Int) { cur = m; dur = c.duration.coerceAtLeast(0) }
                override fun onPlaybackStateChanged(s: Int) { dur = c.duration.coerceAtLeast(0) }
            })
        }, ctx.mainExecutor)
        onDispose { MediaController.releaseFuture(f) }
    }

    val perms = remember { if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE) }
    var trigger by remember { mutableStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val audioOk = r[perms[0]] == true
        denied = !audioOk; if (audioOk) trigger++
    }
    LaunchedEffect(Unit) { launcher.launch(perms) }
    LaunchedEffect(trigger) {
        if (trigger > 0) { songs = withContext(Dispatchers.IO) { scanSongs(ctx) }; scanned = true }
    }
    LaunchedEffect(songs, ctl) {
        val c = ctl ?: return@LaunchedEffect
        if (songs.isNotEmpty() && c.mediaItemCount == 0) { c.setMediaItems(songs); c.prepare(); cur = c.currentMediaItem }
    }
    LaunchedEffect(ctl) { while (true) { ctl?.let { pos = it.currentPosition; dur = it.duration.coerceAtLeast(0) }; delay(400) } }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Nightdrive", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            TextButton(onClick = { launcher.launch(perms) }) { Icon(Icons.Default.Refresh, null, tint = Violet); Spacer(Modifier.width(6.dp)); Text("Rescan", color = Violet) }
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Card).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(110.dp).clip(CircleShape).background(Grad), contentAlignment = Alignment.Center) {
                Text((cur?.mediaMetadata?.title?.firstOrNull()?.uppercase() ?: "♪"), color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(Modifier.height(14.dp))
            Text(cur?.mediaMetadata?.title?.toString() ?: "Nothing playing", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(cur?.mediaMetadata?.artist?.toString() ?: "Pick a song below", color = Mute, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Slider(value = drag ?: (if (dur > 0) pos.toFloat() / dur else 0f), onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { ctl?.seekTo((it * dur).toLong()) }; drag = null },
                colors = SliderDefaults.colors(thumbColor = Pink, activeTrackColor = Violet, inactiveTrackColor = Color(0xFF2A2D55)))
            Row(Modifier.fillMaxWidth()) { Text(fmt(pos), color = Mute, fontSize = 11.sp); Spacer(Modifier.weight(1f)); Text(fmt(dur), color = Mute, fontSize = 11.sp) }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                IconButton(onClick = { shuffle = !shuffle; ctl?.shuffleModeEnabled = shuffle }) { Icon(Icons.Default.Shuffle, "Shuffle", tint = if (shuffle) Pink else Color.White) }
                IconButton(onClick = { ctl?.seekToPrevious() }) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(32.dp)) }
                Box(Modifier.size(64.dp).clip(CircleShape).background(Grad).clickable { ctl?.let { if (it.isPlaying) it.pause() else it.play() } }, contentAlignment = Alignment.Center) {
                    Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Pause" else "Play", tint = Color.White, modifier = Modifier.size(32.dp))
                }
                IconButton(onClick = { ctl?.seekToNext() }) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(32.dp)) }
                IconButton(onClick = { repeat = (repeat + 1) % 3; ctl?.repeatMode = intArrayOf(Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ALL, Player.REPEAT_MODE_ONE)[repeat] }) {
                    Icon(if (repeat == 2) Icons.Default.RepeatOne else Icons.Default.Repeat, "Repeat", tint = if (repeat > 0) Pink else Color.White)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search songs or artists") },
            leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(16.dp))
        Spacer(Modifier.height(8.dp))
        val shown = songs.withIndex().filter { (_, m) -> query.isBlank() || "${m.mediaMetadata.title} ${m.mediaMetadata.artist}".contains(query, true) }
        if (shown.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(when { denied -> "Allow access to music and audio so Nightdrive can find your songs. Tap Rescan to ask again."; !scanned -> "Scanning your phone…"; songs.isEmpty() -> "No songs found on this phone."; else -> "No matches." }, color = Mute, fontSize = 14.sp)
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
            itemsIndexed(shown, key = { _, v -> v.value.mediaId }) { _, (i, m) ->
                val isCur = m.mediaId == cur?.mediaId
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (isCur) Color(0xFF23265A) else Card)
                    .clickable { ctl?.let { it.seekTo(i, 0); it.play() } }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Grad), contentAlignment = Alignment.Center) {
                        Text(m.mediaMetadata.title?.firstOrNull()?.uppercase() ?: "♪", color = Color.White, fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(m.mediaMetadata.title?.toString() ?: "", color = if (isCur) Pink else Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(m.mediaMetadata.artist?.toString() ?: "", color = Mute, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (isCur && playing) Icon(Icons.Default.GraphicEq, null, tint = Pink)
                }
            }
        }
    }
}
