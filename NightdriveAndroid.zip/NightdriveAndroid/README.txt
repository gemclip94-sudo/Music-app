Nightdrive (Android)
1. Install Android Studio (Koala or newer). File > Open > select this folder.
2. Let Gradle sync (accept the prompt to use the bundled Gradle/JDK 17).
3. Plug in your phone (USB debugging on) and press Run. 
4. To get an installable APK: Build > Build Bundle(s)/APK(s) > Build APK(s).
